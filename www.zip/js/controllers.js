var token;

angular.module('starter.controllers', ['ngDialog'])

.controller('LoginCtrl', function($scope, $ionicModal, $http, $state) {

  // With the new view caching in Ionic, Controllers are only called
  // when they are recreated or on app start, instead of every page change.
  // To listen for when this page is active (for example, to refresh data),
  // listen for the $ionicView.enter event:
  //$scope.$on('$ionicView.enter', function(e) {
  //});

  // Create the login modal that we will use later
  $ionicModal.fromTemplateUrl('templates/registration.html', {
    scope: $scope
  }).then(function(modal) {
    $scope.modalReg = modal;
  });
  $ionicModal.fromTemplateUrl('templates/password-1.html', {
    scope: $scope
  }).then(function(modal) {
    $scope.modalRecov1 = modal;
  });
  $ionicModal.fromTemplateUrl('templates/password-2.html', {
    scope: $scope
  }).then(function(modal) {
    $scope.modalRecov2 = modal;
  });
  $ionicModal.fromTemplateUrl('templates/password-3.html', {
    scope: $scope
  }).then(function(modal) {
    $scope.modalRecov3 = modal;
  });

  $scope.regData = {};
  $scope.loginData = {};
  $scope.recovData1 = {};
  $scope.recovData2 = {};
  $scope.recovData3 = {};


  // Triggered in the registration modal to close it
  $scope.closeReg = function() {
    $scope.modalReg.hide();
  };
  // Open the registration modal
  $scope.openReg = function() {
    $scope.modalReg.show();
    //requsts
    var adres = 'http://farm.shop4u.by/rest/web/v1/';
    $http.get(adres+'cities').success(function(response) {
      $scope.cities = response;
      console.log('cities', response);
    });
    $http.get(adres+'education').success(function(response) {
      $scope.educations = response;
      console.log('educations', response);
    });
    $http.get(adres+'firms').success(function(response) {
      $scope.firms = response;
      console.log('firms', response);
    });
    $http.get(adres+'sex').success(function(response) {
      $scope.sexies = response;
      console.log('sexies', response);
    });
    $http.get(adres+'pharmacies').success(function(response) {
      $scope.pharmacies = response;
      console.log('pharmacies', response);
    });
    };

  // Perform the login action when the user submits the login form
  $scope.doReg = function() {
    console.log('Doing reg', $scope.regData);
    $http.post('http://farm.shop4u.by:80/rest/web/v1/join', $scope.regData, function(data, textStatus, xhr) {
      console.log('data', data);
    })
    .error(function(data) {
      console.log('hut zalupa', data);
    })
    .success(function() {
      $scope.closeReg();
    });
    // Simulate a login delay. Remove this and replace with your login
    // code if using a login system
    // $timeout(function() {
    //   $scope.closeReg();
    // }, 1000);
  };

  $scope.doLog = function() {
    $http.post('http://farm.shop4u.by:80/rest/web/v1/login', $scope.loginData, function(data, textStatus, xhr) {
      console.log('data', data);
    })
    .error(function(data) {
      console.log('nevdaha', data);
    })
    .success(function(data) {
      console.log('redirecting to main', data);
      token = data;
      $state.go('app.main');
    })
  };

  $scope.openRecov1 = function() {
    console.log('HERE');
    $scope.closeRecov3();
    $scope.modalRecov1.show();
  };
   $scope.closeRecov1 = function() {
    console.log('HERE');
    $scope.modalRecov1.hide();
  };
  $scope.doRecov1 = function() {
    console.log('scope recov data', $scope.recovData1);
    $http.put('http://farm.shop4u.by:80/rest/web/v1/reset-token', $scope.recovData1, function(data, textStatus, xhr) {
      console.log('recovery data', data);
    })
    .error(function(data) {
      console.log(data);
    })
    .success(function(data) {
      console.log(data, 'my data', $scope.recovData1);
      $scope.closeRecov1();
      $scope.openRecov2();
    })
  };

  $scope.openRecov2 = function() {
    console.log('HERE');
    console.log('modal 1 has removed');
    $scope.modalRecov2.show();
  };
   $scope.closeRecov2 = function() {
    console.log('HERE');
    $scope.modalRecov2.hide();
  };
  $scope.doRecov2 = function() {
    console.log('doing code', $scope.recovData2.reset_token);
    $http.get('http://farm.shop4u.by:80/rest/web/v1/reset-token?reset_token='+$scope.recovData2.reset_token, function(data, textStatus, xhr) {
      console.log('recovery data', data);
    })
    .error(function() {
      console.log('error with code', $scope.recovData2);
    })
    .success(function(data) {
      console.log('success with code', data);
      if (data == false) {
        alert('nepravilno');
      }
      else if (data == true) {
         $scope.openRecov3()
      }
    })
  };

  $scope.openRecov3 = function() {
    console.log('2 object', $scope.recovData2);
    console.log('3 object', $scope.recovData3);
    $scope.recovData3.reset_token = $scope.recovData2.reset_token;
    console.log('modal 2 has removed');
    $scope.modalRecov3.show();
  };
   $scope.closeRecov3 = function() {
    console.log('HERE');
    $scope.modalRecov3.hide();
  };
   $scope.doRecov3 = function() {
    $http.put('http://farm.shop4u.by:80/rest/web/v1/reset-password', $scope.recovData3, function(data, textStatus, xhr) {
      console.log('recovery data', data);
    })
    .error(function() {
      console.log('error with code', $scope.recovData3);
    })
    .success(function(data) {
      //clear all modals
      $scope.modalRecov1.remove();
      $scope.modalRecov2.remove();
      console.log('success with code', data);
      $scope.closeRecov3();
    })
  };

})
.controller('MainCtrl', function($scope, $ionicModal, $http, $state, ngDialog) {
  console.log(1);
  //reg page
  $scope.c   = function() {
    ngDialog.open({ template: 'templates/agreement.html' });
    console.log('privet soglasheniye');
  };

  //main page
  $scope.$on('$ionicView.beforeEnter', function() {
    // console.log(2);
    console.log(token);
  $http.get('http://farm.shop4u.by:80/rest/web/v1/user?expand=education,firm,city,pharmacy,position,avatar&access-token='+token, function(data, textStatus, xhr) {
  })
  .error(function() {
    console.log('error');
  })
  .success(function(data) {
    console.log('success', data);
    $scope.user = data;
    document.getElementById('user_avatar').src = "img/user.png";
    document.getElementById('user_name').innerHTML = data.name;
    document.getElementById('user_education').innerHTML = data.education.name;
    document.getElementById('user_pharm').innerHTML = data.firm.name+', '+data.city.name;
    // document.getElementById('user_city').innerHTML = data.city.name;
    console.log('OSEL', $scope.user);
  }); 

  });
});